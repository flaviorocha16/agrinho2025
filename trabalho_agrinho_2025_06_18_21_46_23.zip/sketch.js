let xJogador = [0, 0, 0, 0];
let yJogador = [75, 150, 225, 300];
let jogador = ["🐔", "🍇", "🚜", "💸" ]
let teclas = ["a", "s", "d", "f"];
let quantidade = jogador.length;
let focused;
let estadoJogo = "descricao";

function setup() {
  createCanvas(400, 400);
  focused = document.hasFocus();
}

function draw() {
  if (estadoJogo === "descricao") {
    telaDescricao(); 
  } else if (estadoJogo === "jogo") {
    ativaJogo(); 
    desenhaJogadores(); 
    desenhaLinhaDeChegada(); 
    verificaVencedor(); 
  }
}

function telaDescricao() {
  background("#00ACFF");
  textSize(20);
  fill("white");
  textAlign(CENTER, CENTER);
  text("TUTORIAL", width / 2, height / 4);
  textSize(16);
  text("aperte a tela e precione a tecla espaço para começar. ", width / 2, height / 3);
text("Após isso, use A, S, D, F para se mover ", width / 2, height / 2);}

function ativaJogo() {
  focused = document.hasFocus(); // Verifica se o canvas está focado
  if (focused) {
    background("#E21538");
  } else 
    background("#32E030");
}

function desenhaJogadores() {
  textSize(40);
  for (let i = 0; i < quantidade; i++) {
    text(jogador[i], xJogador[i], yJogador[i]);
  }
}

function desenhaLinhaDeChegada() {
  fill("white");
  rect(350, 0, 10, 400);
  fill("black");
  for (let yAtual = 0; yAtual < 400; yAtual += 20) {
    rect(350, yAtual, 10, 10);
  }
}

function verificaVencedor() {
  for (let i = 0; i < quantidade; i++) {
    if (xJogador[i] > 350) {
      text(jogador[i] + "ganhou", 100, 200);
       textAlign(CENTER, CENTER);
      noLoop(); // Para o jogo
    }
  }
}

function keyPressed() {
  if (estadoJogo === "descricao") {
    estadoJogo = "jogo"; // Muda para o estado de jogo ao pressionar qualquer tecla
  }
}

function keyReleased() {
  for (let i = 0; i < quantidade; i++) {
    if (key == teclas[i] && focused && estadoJogo === "jogo") {
      xJogador[i] += 10; // Move o jogador de forma fixa
    }
  }
}